# بلاغات الصيانة — AI Maintenance Request Classifier

An app for submitting home-maintenance / craftsman service requests in Arabic. The user
describes their problem in free text, an LLM (Google Gemini) suggests a **category** and
**priority**, the user can adjust either before saving, and every saved request shows up
in a list.

## Tech choice & reasoning

**Next.js 14 (App Router, TypeScript) + Tailwind CSS**, single project, no separate backend repo.

- Next.js API routes (`app/api/**`) run **only on the server**, so the Gemini key lives in
  an environment variable that's never sent to the browser — it satisfies the "don't expose
  the key in the frontend" requirement without standing up a separate Express/Flask service.
- One codebase gives both a real backend and a fully responsive, mobile-first frontend, which
  is the baseline requirement. Deploys as-is to Vercel (or any Node host) with zero extra config.
- Tailwind's mobile-first breakpoints (`sm:`, etc.) are used throughout so the layout is
  designed for a phone screen first and progressively enhanced for larger viewports.
- **Bonus / mobile app**: not built, to stay within scope, but the API is already a clean,
  framework-agnostic HTTP contract (`POST /api/classify`, `GET/POST /api/requests`) — a
  React Native or Flutter app could call the exact same endpoints with no backend changes.
  See "API contract" below.

## Setup

```bash
npm install
cp .env.local.example .env.local
# then edit .env.local and paste a free key from https://aistudio.google.com/app/apikey
npm run dev
```

Open http://localhost:3000.

**No key yet?** The app still runs. `lib/classifier.ts` falls back to a small local
keyword-based classifier (and does the same automatically if a live Gemini call ever
fails), so the flow is demoable end-to-end with or without an API key. When
`GEMINI_API_KEY` is set, every classification goes through Gemini using the exact prompt
specified for the task.

## How it works

1. **New request** (`/`) — a textarea for the problem description and an "تحليل بالذكاء
   الاصطناعي" (Analyze) button. This calls `POST /api/classify`, which builds the required
   Arabic prompt, sends it to `gemini-2.0-flash` with `responseMimeType: "application/json"`,
   and returns an array of `{ description, suggested_category, suggested_priority }`. If the
   text describes more than one unrelated problem, Gemini splits it into multiple objects
   per the prompt's rule — the UI then shows one editable card per issue.
2. Each suggested card has a `<select>` for category and one for priority so the user can
   correct the AI before saving — nothing is persisted until they click "حفظ البلاغ".
3. **Save** — `POST /api/requests` validates the category/priority against the fixed enums,
   stamps an `id` and `createdAt`, appends to storage, and redirects to the list.
4. **All requests** (`/requests`) — reads every saved request (description, category,
   priority, date), newest first, with a colored left border and badge per priority/category.

## Storage

Requests are stored in `data/requests.json` via `lib/store.ts`, which is a small module with
two functions (`getAllRequests`, `addRequests`). This keeps the demo dependency-free — no
database to provision to try it out. Swapping in Postgres/Supabase/SQLite later only means
rewriting `lib/store.ts`; nothing else in the app touches the storage layer directly.

## API contract (reusable by a future mobile app)

`POST /api/classify`
```json
// request
{ "description": "يوجد تسريب مياه تحت حوض المطبخ والإضاءة في غرفة النوم لا تعمل" }

// response
{
  "results": [
    { "description": "...", "suggested_category": "سباكة", "suggested_priority": "عاجل" },
    { "description": "...", "suggested_category": "كهرباء", "suggested_priority": "عادي" }
  ],
  "mocked": false
}
```

`GET /api/requests` → `{ "requests": [{ id, description, category, priority, createdAt }, ...] }`

`POST /api/requests`
```json
{ "items": [{ "description": "...", "category": "سباكة", "priority": "عاجل" }] }
```

## Project structure

```
app/
  page.tsx                 # request submission screen
  requests/page.tsx        # requests list screen
  api/classify/route.ts    # calls Gemini (server-only)
  api/requests/route.ts    # list + save requests
lib/
  classifier.ts            # prompt + Gemini call + local fallback
  store.ts                 # JSON file persistence
  constants.ts / types.ts  # fixed category/priority enums & shared types
data/requests.json         # generated at runtime
```

## Design notes

Arabic, right-to-left throughout (`dir="rtl"` on `<html>`). Two type families — Cairo for
headings, IBM Plex Sans Arabic for body — on a muted paper/ink/navy palette, with priority
communicated redundantly through both color and text (never color alone), so it stays
readable and accessible at every breakpoint.
